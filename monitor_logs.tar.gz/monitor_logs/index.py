from flask import Flask, render_template, request, url_for, redirect
import subprocess
import sys

app = Flask(__name__)

@app.route('/')
@app.route('/index')

def index():
    cmd = ["sh","kube-list.sh"]
    p = subprocess.Popen(cmd,
                         stdout = subprocess.PIPE,
                         stderr=subprocess.PIPE,
                         stdin=subprocess.PIPE)
    out,err = p.communicate()
    lista = out.splitlines()
    return render_template("pods.html",lista = lista)

@app.route('/log', methods=['GET', 'POST'])
def log():
    if request.method == 'POST':
       log = request.form
       podf = request.form.get("pod")
       podn = podf.split(' ') 
       cmd = ["sh","kube-logs.sh",podn[0],podn[1]]
       p = subprocess.Popen(cmd,
                         stdout = subprocess.PIPE,
                         stderr=subprocess.PIPE,
                         stdin=subprocess.PIPE)
       out,err = p.communicate()
       #print(out.decode('utf-8'), file=sys.stderr)
       return render_template("logs.html",log = log,out = out.decode('utf-8'))
    elif request.method == 'GET':
       log = request.args.get("log")
       podf = request.args.get("pod")
       #print(podf, file=sys.stderr)
       podn = podf.split(' ') 
       cmd = ["sh","kube-logs.sh",podn[0],podn[1]]
       p = subprocess.Popen(cmd,
                         stdout = subprocess.PIPE,
                         stderr=subprocess.PIPE,
                         stdin=subprocess.PIPE)
       out,err = p.communicate()
       #print(out.decode('utf-8'), file=sys.stderr)
       return render_template("logs.html",log = podf,out = out.decode('utf-8'))
    else:
       return render_template("pods.html")
         
if __name__ == '__main__':
    app.run(host='0.0.0.0',port=5001,debug=True)

