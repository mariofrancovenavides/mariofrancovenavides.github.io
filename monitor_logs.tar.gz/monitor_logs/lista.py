import subprocess

cmd = ["sh","kube-list.sh"]
p = subprocess.Popen(cmd,
                     stdout = subprocess.PIPE,
                     stderr=subprocess.PIPE,
                     stdin=subprocess.PIPE)
out,err = p.communicate()
#lista = out.split('\n')
print (out)

