#!/bin/bash
export FLASK_APP=index.py ; nohup venv/bin/flask run -h 0.0.0.0 -p 5001 &
