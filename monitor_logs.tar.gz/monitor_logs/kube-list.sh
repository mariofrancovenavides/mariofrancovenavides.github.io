#!/bin/bash
kubectl get pods -A | awk '{print $1" "$2}' 
