#!/bin/bash
kubectl logs --tail=1500 -n $1 $2 | sed -r "s/\x1B\[([0-9]{1,2}(;[0-9]{1,2})?)?[mGK]//g"
